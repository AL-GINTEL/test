enum  SocialLoginOption{
  google,
  facebook,
  apple
}